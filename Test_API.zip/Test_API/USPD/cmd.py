import os

os.system('time')